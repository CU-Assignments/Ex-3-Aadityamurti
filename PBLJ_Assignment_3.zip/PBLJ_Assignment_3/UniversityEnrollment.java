import java.util.*;

class CourseFullException extends Exception {
    public CourseFullException(String message) {
        super(message);
    }
}

class PrerequisiteNotMetException extends Exception {
    public PrerequisiteNotMetException(String message) {
        super(message);
    }
}

class UniversityEnrollment {
    private static final int MAX_ENROLLMENT = 5;
    private static Map<String, Integer> courseEnrollment = new HashMap<>();
    private static Map<String, String> prerequisites = new HashMap<>();
    private static Set<String> completedCourses = new HashSet<>();
    
    static {
        prerequisites.put("AdvancedJava", "CoreJava");
    }
    
    public static void enrollStudent(String course) throws CourseFullException, PrerequisiteNotMetException {
        if (prerequisites.containsKey(course) && !completedCourses.contains(prerequisites.get(course))) {
            throw new PrerequisiteNotMetException("Error: PrerequisiteNotMetException - Complete " + prerequisites.get(course) + " before enrolling in " + course);
        }
        
        courseEnrollment.putIfAbsent(course, 0);
        if (courseEnrollment.get(course) >= MAX_ENROLLMENT) {
            throw new CourseFullException("Error: CourseFullException - Enrollment limit reached for " + course);
        }
        
        courseEnrollment.put(course, courseEnrollment.get(course) + 1);
        System.out.println("Successfully enrolled in " + course);
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        try {
            System.out.print("Enroll in Course: ");
            String course = sc.nextLine();
            enrollStudent(course);
        } catch (CourseFullException | PrerequisiteNotMetException e) {
            System.out.println(e.getMessage());
        } finally {
            sc.close();
        }
    }
}

